<script setup lang="ts">
import { ref } from 'vue'
import CreditCard from '@/components/Card.vue'

const tab = ref<string>('saved')

const showDetails = ref<boolean>(true) 
</script>

<template>
    <main class=" ">
        <div class="router-view min-h-screen pb-2 bg-white rounded-sm m-6 mb-20">
            <div class="tab-bar flex items-center justify-between">
                <div class="flex items-center gap-x-2">
                    <!-- two tab bar -->
                    <button @click="tab='saved'" class="flex items-center p-3 rounded-sm font-Montserrat text-sm font-semibold tracking-tighter"
                        :class="[tab==='saved' ? 'text-[#0FA1DB] border-b border-[#6A94A5]' : 'text-[#0C3F62]']"
                    >
                         Saved Cards
                    </button>
                    <button @click="tab='gd'" class="flex items-center p-3 rounded-sm font-Montserrat text-sm font-semibold tracking-tighter "
                        :class="[tab==='gd' ? 'text-[#0FA1DB] border-b border-[#6A94A5]' : 'text-[#0C3F62]']"
                    >
                         GD Cards
                    </button>
                     
                </div>
                <button class="flex items-center m-2 py-1 px-3 rounded-sm font-Montserrat text-sm font-semibold tracking-tighter bg-[#0FA1DB] text-white">
                    <PlusIcon class="w-3 h-3 mr-1"/> Add Card
                </button>
            </div>

            <div class="grid grid-cols-5 gap-4 m-4">
                <div class="col-span-2 space-y-4">
                    <div>
                        <div class="flex items-center justify-between p-5 bg-[#F8F8F8] rounded">
                            <div class="flex items-center font-Montserrat text-sm text-[#0FA1DB] font-[500] tracking-tighter">
                                <DashboardIcon class="w-4 h-4 mr-3"/>
                                Card Details
                            </div>

                            <div class="p-1 rounded-full bg-[#C2E2EE] text-[#0C3F62]">
                                <DownIcon class="w-3 h-3"/>
                            </div>
                        </div>
                    </div>


                    <div>
                        <div class="flex items-center justify-between p-5 bg-[#F8F8F8] rounded">
                            <div class="flex items-center font-Montserrat text-sm text-[#0FA1DB] font-[500] tracking-tighter">
                                <DashboardIcon class="w-4 h-4 mr-3"/>
                                Card Details
                            </div>

                            <div @click="showDetails = !showDetails" class="cursor-pointer p-1 rounded-full bg-[#C2E2EE] text-[#0C3F62]" :class="[showDetails ? 'rotate-180' : '']">
                                <DownIcon class="w-3 h-3"/>
                            </div>
                        </div>
                        
                        <div v-if="showDetails" class="border border-t-0 mt-0 m-[1px] border-[#6A94A5] transition-all duration-300 " :class="showDetails ? 'block h-auto' : 'hidden h-0'">

                            <div v-for="i in 8" :key="i" class="flex items-center justify-between px-2 py-2 mx-5 border-b border-[#0FA1DB] bg-white"> 
                                <div class="flex items-center">
                                    <div class="p-2 bg-[#C2E2EE] text-[#0FA1DB] rounded-full">
                                        <DownloadIcon class="w-4 h-4"/>
                                    </div>

                                    <div class="flex flex-col items-start ml-2 mt-3">
                                        <div class="font-Montserrat text-sm text-[#0C3F62] font-[500] tracking-tighter">
                                            Ordered Food
                                        </div>
                                        <div class="font-Montserrat text-xs text-[#6A94A5] font-[500] tracking-tighter">
                                            20th Feb 2022
                                        </div>
                                        <div class="font-Montserrat text-xs text-[#0FA1DB] font-[500] tracking-tighter">
                                            Charges applied on credit card
                                        </div>
                                    </div>
                                </div>

                                <div class="flex items-center font-Montserrat text-xs text-red-500 font-[500] tracking-tighter">
                                    -$ 150.50
                                </div>


                            </div>

                        </div>
                    </div>

                </div>


                <div class="col-span-3">
                    <div>
                        <CreditCard
                            cardNumber="1234567890123456"
                            cardHolder="John Doe"
                            expiry="12/26"
                            type="Visa"
                            cvv="123"
                        />
                    </div>
                </div>
            </div>







        </div>

        <div class="flex items-center justify-center bg-[#6A94A5] h-[34px] text-white font-Inter text-xs" >
            © 2022 GIRIRAJ DIGITAL All Rights Reserved.
        </div>

    </main>

</template>


<style lang="scss" scoped>
.tab-bar {
    box-shadow: 0px 1px 2px 0px #6a94a5c5;
}
</style>
