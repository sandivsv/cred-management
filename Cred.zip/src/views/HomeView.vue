<template>
  <main class=" ">
        <div class="router-view h-screen bg-white rounded-sm m-6 mb-20">
            <div class="flex items-center justify-center text-lg text-[#0C3F62] p-10">
                Home 
            </div>
        </div>

        <div class="flex items-center justify-center bg-[#6A94A5] h-[34px] text-white font-Inter text-xs" >
            © 2022 GIRIRAJ DIGITAL All Rights Reserved.
        </div>

    </main>
</template>