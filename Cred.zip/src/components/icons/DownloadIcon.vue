<template>
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 1L8 11M8 11L12 8M8 11L4 8M1 12V13C1 14.1046 1.89543 15 3 15H13C14.1046 15 15 14.1046 15 13V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

</template>