<template>
    <svg width="14" height="11" viewBox="0 0 14 11" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.71429 5.5C8.71429 6.49411 7.94677 7.3 7 7.3C6.05323 7.3 5.28571 6.49411 5.28571 5.5C5.28571 4.50589 6.05323 3.7 7 3.7C7.94677 3.7 8.71429 4.50589 8.71429 5.5Z" stroke="currentColor"/>
<path d="M7 1C4 1 1 3.45455 1 5.5C1 7.54545 4 10 7 10C10 10 13 7.54545 13 5.5C13 3.45455 10 1 7 1Z" stroke="currentColor"/>
</svg>

</template>