<template>
    <svg width="16" height="14" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3 4.57143V11C3 12.1046 3.89543 13 5 13H11C12.1046 13 13 12.1046 13 11V4.57143M3 4.57143L1 6M3 4.57143L8 1L13 4.57143M13 4.57143L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

</template>