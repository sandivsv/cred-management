<template>
    <svg width="15" height="10" viewBox="0 0 15 10" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.5 1L8.32842 7.17158C6.99509 8.50491 6.32843 9.17157 5.5 9.17157C4.67157 9.17157 4.00491 8.50491 2.67157 7.17157L1 5.5" stroke="currentColor" stroke-linecap="round"/>
</svg>

</template>